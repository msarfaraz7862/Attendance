import React, { useState, useEffect } from 'react';
import { Calendar, Check, X, Save } from 'lucide-react';
import { Student, AttendanceRecord, Class } from '../types';

interface AttendanceMarkerProps {
  students: Student[];
  classes: Class[];
  onSaveAttendance: (date: string, records: AttendanceRecord[]) => void;
  getAttendanceForDate: (date: string) => AttendanceRecord[];
}

export default function AttendanceMarker({ students, classes, onSaveAttendance, getAttendanceForDate }: AttendanceMarkerProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedSection, setSelectedSection] = useState<string>('');
  const [attendance, setAttendance] = useState<{ [studentId: string]: 'present' | 'absent' }>({});
  const [hasChanges, setHasChanges] = useState(false);

  const filteredStudents = students.filter(student => {
    if (selectedClass && student.classId !== selectedClass) return false;
    if (selectedSection && student.section !== selectedSection) return false;
    return true;
  });

  const selectedClassData = classes.find(c => c.id === selectedClass);

  useEffect(() => {
    const existingRecords = getAttendanceForDate(selectedDate);
    const attendanceMap: { [studentId: string]: 'present' | 'absent' } = {};
    
    filteredStudents.forEach(student => {
      const record = existingRecords.find(r => r.studentId === student.id);
      attendanceMap[student.id] = record?.status || 'absent';
    });
    
    setAttendance(attendanceMap);
    setHasChanges(false);
  }, [selectedDate, filteredStudents, getAttendanceForDate]);

  const toggleAttendance = (studentId: string) => {
    setAttendance(prev => ({
      ...prev,
      [studentId]: prev[studentId] === 'present' ? 'absent' : 'present'
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    const records: AttendanceRecord[] = Object.entries(attendance).map(([studentId, status]) => {
      const student = students.find(s => s.id === studentId);
      return {
      id: `${studentId}-${selectedDate}`,
      studentId,
      date: selectedDate,
      status,
      classId: student?.classId || '',
      section: student?.section || ''
      };
    });

    onSaveAttendance(selectedDate, records);
    setHasChanges(false);
  };

  const markAllPresent = () => {
    const newAttendance: { [studentId: string]: 'present' | 'absent' } = {};
    filteredStudents.forEach(student => {
      newAttendance[student.id] = 'present';
    });
    setAttendance(newAttendance);
    setHasChanges(true);
  };

  const markAllAbsent = () => {
    const newAttendance: { [studentId: string]: 'present' | 'absent' } = {};
    filteredStudents.forEach(student => {
      newAttendance[student.id] = 'absent';
    });
    setAttendance(newAttendance);
    setHasChanges(true);
  };

  const presentCount = Object.values(attendance).filter(status => status === 'present').length;
  const totalStudents = filteredStudents.length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Mark Attendance</h2>
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
          <div className="flex items-center gap-2">
            <select
              value={selectedClass}
              onChange={(e) => {
                setSelectedClass(e.target.value);
                setSelectedSection('');
              }}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
            >
              <option value="">All Classes</option>
              {classes.map(cls => (
                <option key={cls.id} value={cls.id}>{cls.name}</option>
              ))}
            </select>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
              disabled={!selectedClass}
            >
              <option value="">All Sections</option>
              {selectedClassData?.sections.map(section => (
                <option key={section} value={section}>{section}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <Calendar size={20} className="text-gray-600 dark:text-gray-300" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
            />
          </div>
          {hasChanges && (
            <button
              onClick={handleSave}
              className="bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Save size={16} />
              Save Attendance
            </button>
          )}
        </div>
      </div>

      {totalStudents > 0 && (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center mb-4">
            <div className="text-sm text-gray-600 dark:text-gray-300">
              Present: <span className="font-semibold text-green-600 dark:text-green-400">{presentCount}</span> / 
              <span className="font-semibold">{totalStudents}</span> students
              {totalStudents > 0 && (
                <span className="ml-2">
                  ({Math.round((presentCount / totalStudents) * 100)}%)
                </span>
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={markAllPresent}
                className="bg-green-100 hover:bg-green-200 dark:bg-green-900 dark:hover:bg-green-800 text-green-700 dark:text-green-300 px-3 py-1 rounded text-sm transition-colors"
              >
                Mark All Present
              </button>
              <button
                onClick={markAllAbsent}
                className="bg-red-100 hover:bg-red-200 dark:bg-red-900 dark:hover:bg-red-800 text-red-700 dark:text-red-300 px-3 py-1 rounded text-sm transition-colors"
              >
                Mark All Absent
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredStudents.sort((a, b) => {
              // First try to sort by numeric roll number
              const aNum = parseInt(a.rollNumber);
              const bNum = parseInt(b.rollNumber);
              if (!isNaN(aNum) && !isNaN(bNum)) {
                return aNum - bNum;
              }
              // If not numeric, sort alphabetically
              return a.rollNumber.localeCompare(b.rollNumber);
            }).map((student) => {
              const studentClass = classes.find(c => c.id === student.classId);
              return (
              <div
                key={student.id}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
                  attendance[student.id] === 'present'
                    ? 'border-green-300 bg-green-50 dark:border-green-600 dark:bg-green-900/20'
                    : 'border-red-300 bg-red-50 dark:border-red-600 dark:bg-red-900/20'
                }`}
                onClick={() => toggleAttendance(student.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-800 dark:text-white">{student.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Roll: {student.rollNumber}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {studentClass?.name} - {student.section}
                    </p>
                  </div>
                  <div className={`p-2 rounded-full ${
                    attendance[student.id] === 'present'
                      ? 'bg-green-500 text-white'
                      : 'bg-red-500 text-white'
                  }`}>
                    {attendance[student.id] === 'present' ? <Check size={16} /> : <X size={16} />}
                  </div>
                </div>
                <div className="mt-2">
                  <span className={`text-sm font-medium ${
                    attendance[student.id] === 'present' ? 'text-green-700' : 'text-red-700'
                  } ${
                    attendance[student.id] === 'present' ? 'dark:text-green-300' : 'dark:text-red-300'
                  }`}>
                    {attendance[student.id] === 'present' ? 'Present' : 'Absent'}
                  </span>
                </div>
              </div>
            );
            })}
          </div>
        </div>
      )}

      {totalStudents === 0 && (
        <div className="text-center py-12">
          <Calendar size={48} className="mx-auto text-gray-400 dark:text-gray-500 mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No students found for the selected class and section.</p>
        </div>
      )}
    </div>
  );
}