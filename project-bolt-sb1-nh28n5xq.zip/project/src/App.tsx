import React, { useState } from 'react';
import { Users, Calendar, BarChart3, GraduationCap, School } from 'lucide-react';
import { Student, AttendanceRecord, Class } from './types';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useTheme } from './hooks/useTheme';
import ClassManager from './components/ClassManager';
import StudentManager from './components/StudentManager';
import AttendanceMarker from './components/AttendanceMarker';
import AttendanceHistory from './components/AttendanceHistory';
import ThemeToggle from './components/ThemeToggle';

type TabType = 'classes' | 'students' | 'attendance' | 'history';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('classes');
  const [classes, setClasses] = useLocalStorage<Class[]>('attendance-classes', []);
  const [students, setStudents] = useLocalStorage<Student[]>('attendance-students', []);
  const [attendanceRecords, setAttendanceRecords] = useLocalStorage<AttendanceRecord[]>('attendance-records', []);
  const { isDark, toggleTheme } = useTheme();

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const handleAddClass = (classData: Omit<Class, 'id'>) => {
    const newClass: Class = {
      ...classData,
      id: generateId()
    };
    setClasses([...classes, newClass]);
  };

  const handleEditClass = (id: string, classData: Omit<Class, 'id'>) => {
    setClasses(classes.map(cls => 
      cls.id === id ? { ...classData, id } : cls
    ));
  };

  const handleDeleteClass = (id: string) => {
    if (window.confirm('Are you sure you want to delete this class? This will also remove all students and attendance records for this class.')) {
      setClasses(classes.filter(cls => cls.id !== id));
      setStudents(students.filter(student => student.classId !== id));
      setAttendanceRecords(attendanceRecords.filter(record => record.classId !== id));
    }
  };

  const handleAddStudent = (studentData: Omit<Student, 'id'>) => {
    const newStudent: Student = {
      ...studentData,
      id: generateId()
    };
    setStudents([...students, newStudent]);
  };

  const handleEditStudent = (id: string, studentData: Omit<Student, 'id'>) => {
    setStudents(students.map(student => 
      student.id === id ? { ...studentData, id } : student
    ));
  };

  const handleDeleteStudent = (id: string) => {
    if (window.confirm('Are you sure you want to delete this student? This will also remove all their attendance records.')) {
      setStudents(students.filter(student => student.id !== id));
      setAttendanceRecords(attendanceRecords.filter(record => record.studentId !== id));
    }
  };

  const handleSaveAttendance = (date: string, records: AttendanceRecord[]) => {
    // Remove existing records for this date
    const filteredRecords = attendanceRecords.filter(record => record.date !== date);
    // Add new records
    setAttendanceRecords([...filteredRecords, ...records]);
  };

  const getAttendanceForDate = (date: string): AttendanceRecord[] => {
    return attendanceRecords.filter(record => record.date === date);
  };

  const tabs = [
    { id: 'classes' as TabType, label: 'Manage Classes', icon: School },
    { id: 'students' as TabType, label: 'Manage Students', icon: Users },
    { id: 'attendance' as TabType, label: 'Mark Attendance', icon: Calendar },
    { id: 'history' as TabType, label: 'View History', icon: BarChart3 }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <GraduationCap size={24} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">AttendanceTracker</h1>
                <p className="text-sm text-gray-600 dark:text-gray-300">Student Attendance Management</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-600 dark:text-gray-300">
                Classes: <span className="font-semibold">{classes.length}</span> | 
                Total Students: <span className="font-semibold">{students.length}</span>
              </div>
              <ThemeToggle isDark={isDark} onToggle={toggleTheme} />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <Icon size={18} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'classes' && (
          <ClassManager
            classes={classes}
            onAddClass={handleAddClass}
            onEditClass={handleEditClass}
            onDeleteClass={handleDeleteClass}
          />
        )}

        {activeTab === 'students' && (
          <StudentManager
            students={students}
            classes={classes}
            onAddStudent={handleAddStudent}
            onEditStudent={handleEditStudent}
            onDeleteStudent={handleDeleteStudent}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceMarker
            students={students}
            classes={classes}
            onSaveAttendance={handleSaveAttendance}
            getAttendanceForDate={getAttendanceForDate}
          />
        )}

        {activeTab === 'history' && (
          <AttendanceHistory
            students={students}
            classes={classes}
            attendanceRecords={attendanceRecords}
          />
        )}
      </main>
    </div>
  );
}

export default App;