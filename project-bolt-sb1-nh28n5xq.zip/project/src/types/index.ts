export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  email?: string;
  classId: string;
  section: string;
}

export interface Class {
  id: string;
  name: string;
  sections: string[];
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string;
  status: 'present' | 'absent';
  classId: string;
  section: string;
}

export interface DailyAttendance {
  date: string;
  records: AttendanceRecord[];
}